# Fake Elytra Shops Preview (Fabric 1.21.11)

A small **client-side cosmetic preview mod**. When a server menu opens with a title containing `Shops`, it adds an `Elytra preview` button. The button opens a screen rendering Minecraft's own vanilla Elytra item icon.

## Important multiplayer limitation

This is intentionally a visual preview, not a real item. A client-only mod cannot insert an item into a multiplayer server's shop GUI or inventory, create a server-authoritative dropped item, equip an item, or grant Elytra flight. Those actions are controlled by the server. To make an Elytra purchasable, droppable, wearable, and usable for flight, the server owner must configure the shop and grant a genuine Elytra (or install a compatible server-side plugin/mod). Normal vanilla Elytra flight also requires the server to allow it.

The mod targets a menu whose **screen title** contains `Shops`. Some shop plugins use a different title; in that case the button will not appear until the title match is adjusted for that server's GUI. It does not hook the `/shop` command.

## Build

Requirements: JDK 21 and Gradle 8.14+ (Fabric Loom 1.14.x).

From this folder run:

```bash
gradle build
```

The remapped mod jar will be in `build/libs/`. Install that jar in your client's `mods` folder along with Fabric Loader and Fabric API for Minecraft 1.21.11.

## Versions

- Minecraft: 1.21.11
- Fabric Loader: 0.18.1
- Fabric API: 0.141.1+1.21.11
- Official Mojang mappings
