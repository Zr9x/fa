package com.example.fakeelytrashops;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

import java.util.Locale;

public final class FakeElytraShopsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            String title = screen.getTitle().getString().toLowerCase(Locale.ROOT);
            // Deliberately target a menu titled "Shops"; this does not react to /shop.
            if (!title.equals("shops") && !title.contains("shops")) return;

            int x = scaledWidth / 2 + 82;
            int y = scaledHeight / 2 - 10;
            screen.addRenderableWidget(Button.builder(Component.literal("Elytra preview"), button ->
                    client.setScreen(new ElytraPreviewScreen(screen)))
                    .bounds(x, y, 92, 20)
                    .build());
        });
    }
}
