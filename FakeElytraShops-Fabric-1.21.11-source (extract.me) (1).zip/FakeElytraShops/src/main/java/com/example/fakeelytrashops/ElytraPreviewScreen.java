package com.example.fakeelytrashops;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class ElytraPreviewScreen extends Screen {
    private final Screen parent;
    private final ItemStack elytra = new ItemStack(Items.ELYTRA);

    public ElytraPreviewScreen(Screen parent) {
        super(Component.literal("Elytra preview"));
        this.parent = parent;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics, mouseX, mouseY, partialTick);
        super.render(graphics, mouseX, mouseY, partialTick);

        int cx = width / 2;
        int cy = height / 2;
        graphics.drawCenteredString(font, Component.literal("Vanilla Elytra"), cx, cy - 48, 0xFFFFFF);
        graphics.renderItem(elytra, cx - 8, cy - 20);
        graphics.drawCenteredString(font, Component.literal("Cosmetic preview only"), cx, cy + 12, 0xAAAAAA);
        graphics.drawCenteredString(font, Component.literal("A real server Elytra is required to fly or drop it."), cx, cy + 27, 0xAAAAAA);
        graphics.drawCenteredString(font, Component.literal("Press ESC to return"), cx, cy + 48, 0xFFFFFF);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }
}
